import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Row, Col, Card, CardBody } from 'reactstrap';

import { getLoggedInUser } from '../helpers/authUtils';
import Loader from '../components/Loader';
import queryString from 'query-string';
import PropTypes from 'prop-types'
import axios from 'axios';


class DefaultDashboard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            user: getLoggedInUser(),
            ingredients: []
        };
    }

    componentDidMount() {
        try
        {
          const url ='http://localhost:5000/api/ingredients/';
          axios.get(url).then(response => response.data)
          .then((data) => {
            this.setState({ ingredients: data })
            console.log("query the ingredients")
            console.log(this.state.ingredients)

           })
       }catch(E){
         console.log(E)
       }

      }

    render() {

        return (
            <React.Fragment>
                <div className="">
                    { /* preloader */}
                    {this.props.loading && <Loader />}

                    <Row>
                        <Col lg={12}>
                            <div className="page-title-box">

                                <h4 className="page-title">My Refrigerator</h4>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg={12}>
                            <Card>
                                <CardBody>
                                    Whats in your fridge?
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg={12}>
                            <div className="page-title-box">

                                <h4 className="page-title">Add to Fridge</h4>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg={6}>
                            <Card>
                                <CardBody>

                                <span style={{ color: 'black' }}> Ingredients: </span>
                                {
                                  this.state.ingredients.map((ingredient, index2) => (

                                    <li style={{ padding: '1px' }} key={ingredient.name}>
                                    <span style={{ color: 'black' }}> ingredient name: </span> {ingredient.name} <br />
                                    </li>

                                  ))
                                }
                                  <br/><br/>
                                  acorn squash <button>Add to Cart</button>
                                  <br/>---the value above is hardcoded---
                                  <br/>---can't authenticate with ExpressJS for some reason
                                </CardBody>
                            </Card>
                        </Col>

                        <Col lg={6}>
                            <Card>
                                <CardBody>
                                  Cart:

                                  <br/>
                                  <br/>
                                  
                                  curry powder<button>Remove from Cart</button>
                                  <br/>
                                </CardBody>
                                <button>Submit</button>
                            </Card>
                        </Col>
                    </Row>

                </div>
            </React.Fragment>
        )
    }
}


export default connect()(DefaultDashboard);
