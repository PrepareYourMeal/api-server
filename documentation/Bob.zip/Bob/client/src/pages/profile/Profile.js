import React, { Component } from 'react';
import { connect } from 'react-redux';
import queryString from 'query-string';
import PropTypes from 'prop-types'
import axios from 'axios';
import {
    Row,
    Col,
    Card,
    CardBody,
    CardImg,
    CardText,
    CardTitle,
    CardDeck,
    Collapse,
    CardHeader,
    CardFooter,
    CardSubtitle,
    Button
} from 'reactstrap';

import { getLoggedInUser } from '../../helpers/authUtils';
import Loader from '../../components/Loader';


class Profile extends Component {

    constructor(props) {
        super(props);
        this.state = {
            user: null,
            isAuthenticated: false,
            recipes: [],
            email: "",
            name: "",
            googleId: "",
            photoURL: ""
        };
        console.log("-2")
        console.log(props)
        console.log("-1")
        console.log(props.children)
    }

    componentDidMount() {
        const url ='http://localhost:5000/api/recipes?size=12';
        axios.get(url).then(response => response.data)
        .then((data) => {
          this.setState({
            recipes: data,
            isAuthenticated: this.props.isAuthenticated,
            user: this.props.thisUser,
            email: this.props.thisUser.email.toString(),
            name: this.props.thisUser.name.toString(),
            googleId: this.props.thisUser.googleId.toString(),
            photoURL: this.props.thisUser.photo.toString()
          })
          console.log(this.state.user.email)
          console.log("PROFILE PAGE PROPS")
          console.log(this.props)



         })
      }



      getEmail = () => {
        return this.state.email
      }
      getName = () => {
        return this.state.name
      }
      getGoogleId = () => {
        return this.state.googleId
      }
      getPhotoURL = () => {
        return this.state.photoURL
      }

      getData = () => {
        const url = 'http://localhost:5000/api/recipes?size=12'

        axios.get(url).then(response => response.data)
          .then((data) => {
          this.setState({recipes: data})
          console.log(this.state.recipes)
          console.log(this.state.user)
          })

      };

      getDataVegetarian = () => {
        const url = 'http://localhost:5000/api/recipes/?pageNo=1&size=10&vegetarian=true'

        axios.get(url).then(response => response.data)
          .then((data) => {
          this.setState({recipes: data})
          console.log(this.state.recipes)
          })

      };
      getDataVegan = () => {
        const url = 'http://localhost:5000/api/recipes/?pageNo=1&size=10&vegan=true'

        axios.get(url).then(response => response.data)
          .then((data) => {
          this.setState({recipes: data})
          console.log(this.state.recipes)
          })

      };
      getDataGlutenFree = () => {
        const url = 'http://localhost:5000/api/recipes/?pageNo=1&size=10&glutenFree=true'

        axios.get(url).then(response => response.data)
          .then((data) => {
          this.setState({recipes: data})
          console.log(this.state.recipes)
          })

      };
      getDataDairyFree = () => {
        const url = 'http://localhost:5000/api/recipes/?pageNo=1&size=10&dairyFree=true'

        axios.get(url).then(response => response.data)
          .then((data) => {
          this.setState({recipes: data})
          console.log(this.state.recipes)
          })

      };
      getDataKetogenic = () => {
        const url = 'http://localhost:5000/api/recipes/?pageNo=1&size=10&ketogenic=true'

        axios.get(url).then(response => response.data)
          .then((data) => {
          this.setState({recipes: data})
          console.log(this.state.recipes)
          })

      };

    render() {

        return (
            <React.Fragment>
                <div className="">
                    { /* preloader */}
                    {this.props.loading && <Loader />}

                    <Row>
                        <Col lg={12}>
                            <div className="page-title-box">

                                <h4 className="page-title">Profile</h4>

                                <h4></h4>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg={12}>

                            <Card>
                                <CardBody>
                                   Profile Information:
                                   <br />
                                  <br/>
                                   Email: {this.getEmail()}
                                   <br />
                                   Name: {this.getName()}
                                   <br />
                                   Google ID: {this. getGoogleId()}
                                   <br />
                                   Photo URL: {this.getPhotoURL()}

                                   <br />
                                   <br />
                                   This information is taken from the App.js's "user" Object, profile routes aren't working properly
                                   <br /> /api/profile/me -- there's no profile for me
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </div>
            </React.Fragment>
        )
    }
}


export default connect()(Profile);
