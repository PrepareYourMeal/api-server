import React, { Component, Suspense } from "react";
import { Container } from 'reactstrap';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom'
import queryString from "query-string";
import axios from 'axios';
import { loadUser } from '../actions/authActions';
import setAuthToken from '../utils/setAuthToken';



const Topbar = React.lazy(() => import("./Topbar"));
const Topbar2 = React.lazy(() => import("../frontend/Topbar"));
const Navbar = React.lazy(() => import("./Navbar"));
const Footer = React.lazy(() => import("./Footer"));
const NoAuthRecipes = React.lazy(() => import("../frontend/recipes/Recipes"));
const loading = () => <div className="text-center"></div>;

class AuthLayout extends Component {


    constructor(props) {
        super(props);
        this._isMounted = false;

        this.toggleMenu = this.toggleMenu.bind(this);
        this.state = {
            user: null,
            isAuthLayoutAuthenticated: false,
            isMenuOpened: false
        }
    }

    signOut(e) {
        e.preventDefault();
        this.props.history.push("/login");
    }

    setLogout = () => {

      this.props.handleLogout();
    }

    toggleMenu = (e) => {
        //e.preventDefault();
        this.setState({ isMenuOpened: !this.state.isMenuOpened });
    }

    async componentDidMount() {
        this._isMounted = true;
        try {

        console.log("1 testestt")
        console.log(this.props)

        let query = queryString.parse(this.props.location.search);

        if (query.token) {
            console.log("2")

            let userId = query.userId;
            let token = query.token;
            window.localStorage.setItem("accessJWT", token);
            console.log("3")
            let user;

            console.log("Before -----------")
            console.log(this.props)

            await axios
            .get(`/api/users/?token=${token}`, { withCredentials: true })
            .then(result => {
              if (this._isMounted === true) {
                this.setState({
                  user: result.data,
                  isAuthLayoutAuthenticated: true
                });
                console.log(result.data)

                this.props.authenticate(result.data);

                console.log("After-----------")
                console.log(this.props)


              }
              this._isMounted = false;
              console.log("REACHED HERE")
              this.props.history.push('/recipes');
            });



            console.log("4")
            console.log(user);

            console.log("4.5")
            console.log(this.state);
            //this.setState({ user: user.data, isAuthLayoutAuthenticated: true });

            //this.props.authenticate(user.data);


            //this.setState({ user: user, isAuthenticated: true, name: name });
            console.log("5.0")
            console.log(this.state);


            //Bob Coding



            console.log("5")

            //

        }
      }
        catch (E){
        console.log(E);
        console.log("catching")
      }
    }

    componentWillUnmount() {
      this._isMounted = false;
    }

    renderRedirectToRoot = () => {
        if (this.props.isAuthenticated){
          return <Redirect to='/' appProps={this.props.isAuthenticated} />
        }
    }

    render() {
        //const children = this.props.children || null;

        const children = React.Children.map(this.props.children, (child, index) => {
            return React.cloneElement(child, {
                index,
                isAuthenticated: this.props.isAuthenticated,
                thisUser: this.props.user

                //someFunction: () => this.setState({ activeIndex: index })
            });
        });

        console.log("OUPUT THE CHILDREN")
        console.log(children)
        let topbar;
        if(this.props.isAuthenticated){
          topbar = <Topbar
          rightSidebarToggle={this.toggleRightSidebar}
          menuToggle={this.toggleMenu}
          logout = {this.setLogout}
          isMenuOpened={this.state.isMenuOpened}


          {...this.props} />;;
        }else{
          topbar = <Topbar2 rightSidebarToggle={this.toggleRightSidebar} menuToggle={this.toggleMenu} isMenuOpened={this.state.isMenuOpened} {...this.props} />;
        }


        return (
            <div className="app">
                <header id="topnav">
                    <Suspense fallback={loading()}>
                    {topbar}

                        <Navbar isMenuOpened={this.state.isMenuOpened} {...this.props} />
                    </Suspense>
                </header>

                <div className="wrapper">
                    <Container fluid>
                        <Suspense fallback={loading()}>

                            {children}
                        </Suspense>
                    </Container>
                </div>

                <Footer />

            </div>
        );
    }
}

//const mapStateToProps = (state) => {
//    return {
//        //user: state.Auth.user
//    }
//}
//const mapStateToProps = state => ({
//    isAuthenticated: state.auth.isAuthenticated
//});

//export default connect(mapStateToProps, null)(AuthLayout);
export default connect()(AuthLayout);
